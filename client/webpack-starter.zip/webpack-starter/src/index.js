import message from './message';
import './css/style.css';

console.log(message);
